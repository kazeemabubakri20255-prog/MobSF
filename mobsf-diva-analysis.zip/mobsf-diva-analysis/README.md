# Static Analysis of DIVA with MobSF

A static security analysis of **DIVA (Damn Insecure and Vulnerable App)**, a deliberately vulnerable Android app, using the [Mobile Security Framework (MobSF)](https://github.com/MobSF/Mobile-Security-Framework-MobSF).

> **Scope:** Static analysis only. Nothing was executed or exploited. Findings are scanner indicators that I checked against the evidence, not confirmed exploits. Only an intentionally vulnerable practice app was analysed.

## Target

| Item | Value |
|---|---|
| App | DIVA 1.0 (`jakhar.aseem.diva`) |
| Min / Target SDK | 15 / 23 |
| SHA-256 | `5cefc51fce9bd760b92ab2340477f4dda84b4ae0c5d04a8c9493e4fe34fab7c5` |
| Tool | MobSF v4.5.4 |
| MobSF score | 36/100 (High risk) |

The APK is not included in this repository. It belongs to its original authors; the SHA-256 above identifies the exact file I analysed.

## Key findings

| # | Finding | Severity | Recommended fix |
|---|---|---|---|
| 1 | Debuggable build (`android:debuggable=true`) | High | Disable in release builds; fail the build if set |
| 2 | Exported, unprotected `NotesProvider` | Warning | `exported=false`, or a signature-level permission |
| 3 | Insecure external storage use (CWE-276) | Warning | App-private storage, Android Keystore |
| 4 | Raw SQL queries (CWE-89) | Warning | Parameterised queries |
| 5 | Exported activities (`APICredsActivity`, `APICreds2Activity`) | Warning | `exported=false` unless needed |
| 6 | `allowBackup=true` | Warning | Disable, or exclude sensitive data |
| 7 | Very old `minSdk` (15) | High | Raise to API 29+ |
| 8 | Debug signing certificate, v1-only signature | High | Protected release key, v2+ signing |

## Method

1. Downloaded the APK and verified its SHA-256 locally.
2. Uploaded it to MobSF and reviewed the manifest, code, certificate and permission results.
3. For each finding: read the evidence, judged the realistic impact, and proposed a fix.

## Repository contents

| Path | What it is |
|---|---|
| [`report/`](report/Week7_MobSF_Static_Analysis_Report.pdf) | Full write-up: findings, three detailed investigations, permissions analysis, recommendations |
| [`evidence/`](evidence/) | Screenshots supporting the report |
| [`raw-output/`](raw-output/mobsf-scan-report.pdf) | The unedited MobSF scan export |

## Evidence

![MobSF overview](evidence/02-mobsf-overview.png)
![Manifest analysis](evidence/05-manifest-analysis.png)
![Code analysis](evidence/06-code-analysis.png)

## What I learned

A scanner finding is an indicator, not a verdict. Each one needs evidence, context and a realistic impact assessment. Confirming exploitation would need dynamic testing, which is the logical next step.

## Disclaimer

For educational purposes only. Analyse only applications you own or are authorised to test.

## Author

Kazeem Abubakri, CyberProwess Bootcamp 2026
